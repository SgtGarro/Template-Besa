<?php
add_action( 'besa_before_header_mobile', 'besa_the_hook_header_mobile_menu_all_page', 10 );
add_action( 'besa_footer_mobile_content', 'besa_the_icon_wishlist_footer_mobile', 10 );
add_action( 'besa_header_mobile_content', 'besa_the_button_mobile_menu', 5 );
add_action( 'besa_header_mobile_content', 'besa_the_icon_home_page_mobile', 10 );