<?php
/**
 * The template for displaying the footer
 *
 * Contains the closing of the "site-content" div and all content after.
 *
 * @package WordPress
 * @subpackage Besa
 * @since Besa 1.0
 */

get_template_part( 'page-templates/footer' );
